package com.comicshop.ui;

import com.comicshop.data.DataStore;
import com.comicshop.model.Book;
import com.comicshop.model.Promo;
import com.comicshop.service.CartService;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.List;

/**
 * Контроллер главной страницы: акции, популярные товары, новинки.
 */
public class HomeController {

    @FXML private FlowPane promosBox;   // блок из 3 акций
    @FXML private FlowPane popularBox;  // популярные товары
    @FXML private FlowPane newBox;      // новинки

    @FXML
    public void initialize() {
        DataStore store = DataStore.getInstance();

        if (promosBox != null) {
            for (Promo promo : store.getPromos()) {
                promosBox.getChildren().add(createPromoCard(promo));
            }
        }
        if (popularBox != null) {
            for (Book book : store.getPopular()) {
                popularBox.getChildren().add(createBookCard(book));
            }
        }
        if (newBox != null) {
            for (Book book : store.getNew()) {
                newBox.getChildren().add(createBookCard(book));
            }
        }
    }

    /** Карточка акции. */
    private VBox createPromoCard(Promo promo) {
        VBox card = new VBox(6);
        card.getStyleClass().add("promo-card");
        card.setPadding(new Insets(14));
        card.setPrefWidth(240);

        Label discount = new Label("−" + promo.getDiscountPercent() + "%");
        discount.getStyleClass().add("label-accent");
        discount.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Label title = new Label(promo.getTitle());
        title.setStyle("-fx-font-weight: bold;");

        Label desc = new Label(promo.getDescription());
        desc.setWrapText(true);

        card.getChildren().addAll(discount, title, desc);
        return card;
    }

    /** Карточка товара с кнопкой «В корзину». */
    private VBox createBookCard(Book book) {
        VBox card = new VBox(6);
        card.getStyleClass().add("book-card");
        card.setPadding(new Insets(12));
        card.setPrefWidth(200);

        // Обложка-заглушка
        Region cover = new Region();
        cover.getStyleClass().add("book-cover");
        cover.setPrefSize(176, 220);

        Label title = new Label(book.getTitle());
        title.setWrapText(true);
        title.setStyle("-fx-font-weight: bold;");

        Label author = new Label(book.getAuthor());
        Label price = new Label(String.format("%.0f ₽", book.getPrice()));
        price.getStyleClass().add("label-accent");
        Label rating = new Label("★ " + book.getRating());

        Button addBtn = new Button("В корзину");
        addBtn.getStyleClass().add("button-primary");
        addBtn.setOnAction(e -> {
            CartService.getInstance().addBook(book, 1);
            if (MainController.getInstance() != null) {
                MainController.getInstance().updateStatus();
            }
        });

        card.getChildren().addAll(cover, title, author, price, rating, addBtn);
        return card;
    }

    /** Удобный метод (на случай ручного создания списка карточек). */
    @SuppressWarnings("unused")
    private void fill(FlowPane box, List<Book> books) {
        for (Book b : books) {
            box.getChildren().add(createBookCard(b));
        }
    }
}
