package com.comicshop.ui;

import com.comicshop.data.DataStore;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * Контроллер аккаунта: вход (email + пароль), регистрация, отображение
 * имени пользователя после входа. Подсказка: Демо ivan@mail.ru / 1234.
 */
public class AccountController {

    // --- Поля входа ---
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private Label loginMessage;     // сообщение об ошибке/успехе входа

    // --- Поля регистрации ---
    @FXML private TextField regNameField;
    @FXML private TextField regEmailField;
    @FXML private PasswordField regPasswordField;
    @FXML private TextField regPhoneField;
    @FXML private TextField regAddressField;
    @FXML private Label registerMessage;

    // --- Статус ---
    @FXML private Label welcomeLabel;     // "Здравствуйте, Имя"

    private final DataStore store = DataStore.getInstance();

    @FXML
    public void initialize() {
        refreshWelcome();
    }

    /** Вход: вызывает DataStore.login(). */
    @FXML
    public void onLogin() {
        String email = emailField != null ? emailField.getText() : "";
        String password = passwordField != null ? passwordField.getText() : "";

        boolean ok = store.login(email, password);
        if (loginMessage != null) {
            loginMessage.setText(ok ? "Вход выполнен" : "Неверный email или пароль");
        }
        if (ok) {
            refreshWelcome();
            if (MainController.getInstance() != null) {
                MainController.getInstance().updateStatus();
            }
        }
    }

    /** Регистрация нового пользователя. */
    @FXML
    public void onRegister() {
        String name = regNameField != null ? regNameField.getText() : "";
        String email = regEmailField != null ? regEmailField.getText() : "";
        String password = regPasswordField != null ? regPasswordField.getText() : "";
        String phone = regPhoneField != null ? regPhoneField.getText() : "";
        String address = regAddressField != null ? regAddressField.getText() : "";

        boolean ok = store.register(name, email, password, phone, address);
        if (registerMessage != null) {
            registerMessage.setText(ok
                    ? "Регистрация успешна, вы вошли"
                    : "Не удалось зарегистрироваться (заполните поля или email занят)");
        }
        if (ok) {
            refreshWelcome();
            if (MainController.getInstance() != null) {
                MainController.getInstance().updateStatus();
            }
        }
    }

    /** Выход из аккаунта. */
    @FXML
    public void onLogout() {
        store.logout();
        refreshWelcome();
        if (MainController.getInstance() != null) {
            MainController.getInstance().updateStatus();
        }
    }

    private void refreshWelcome() {
        if (welcomeLabel == null) {
            return;
        }
        welcomeLabel.setText(store.isLoggedIn()
                ? "Здравствуйте, " + store.getCurrentUser().getName()
                : "Вы не вошли в аккаунт");
    }
}
