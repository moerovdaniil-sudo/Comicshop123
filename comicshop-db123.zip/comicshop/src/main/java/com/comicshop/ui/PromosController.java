package com.comicshop.ui;

import com.comicshop.data.DataStore;
import com.comicshop.model.Promo;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;

/**
 * Контроллер раздела «Акции»: карточки акций с процентом скидки и описанием.
 */
public class PromosController {

    @FXML private FlowPane promosBox;

    @FXML
    public void initialize() {
        if (promosBox == null) {
            return;
        }
        for (Promo promo : DataStore.getInstance().getPromos()) {
            promosBox.getChildren().add(createPromoCard(promo));
        }
    }

    private VBox createPromoCard(Promo promo) {
        VBox card = new VBox(8);
        card.getStyleClass().add("promo-card");
        card.setPadding(new Insets(18));
        card.setPrefWidth(300);

        Label discount = new Label("−" + promo.getDiscountPercent() + "%");
        discount.getStyleClass().add("label-accent");
        discount.setStyle("-fx-font-size: 32px; -fx-font-weight: bold;");

        Label title = new Label(promo.getTitle());
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Label desc = new Label(promo.getDescription());
        desc.setWrapText(true);

        card.getChildren().addAll(discount, title, desc);
        return card;
    }
}
