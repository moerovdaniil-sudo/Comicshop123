package com.comicshop.ui;

import com.comicshop.data.DataStore;
import com.comicshop.model.Book.BookType;
import com.comicshop.service.CartService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;

/**
 * Главный контроллер окна. Управляет навигацией (загрузка FXML в центр
 * BorderPane) и отображением статуса корзины и пользователя в сайдбаре.
 */
public class MainController {

    /** Ссылка на текущий экземпляр для обновления статуса из дочерних контроллеров. */
    private static MainController instance;

    @FXML private BorderPane rootPane;     // корневой BorderPane
    @FXML private Label cartStatusLabel;   // "Корзина: N шт." / "Корзина: пуста"
    @FXML private Label userStatusLabel;   // "👤 Имя" / "Гость"

    @FXML
    public void initialize() {
        instance = this;
        updateStatus();
        loadPage("home.fxml"); // стартовый экран — Главная
    }

    public static MainController getInstance() {
        return instance;
    }

    // ===================== Навигация (привязки onAction в FXML) =====================

    @FXML private void onHome()    { loadPage("home.fxml"); }
    @FXML private void onComics()  { loadCatalog("comics.fxml", BookType.COMIC); }
    @FXML private void onManga()   { loadCatalog("manga.fxml", BookType.MANGA); }
    @FXML private void onSearch()  { loadPage("search.fxml"); }
    @FXML private void onCart()    { loadPage("cart.fxml"); }
    @FXML private void onPromos()  { loadPage("promos.fxml"); }
    @FXML private void onAccount() { loadPage("account.fxml"); }

    /** Загрузить FXML-страницу в центральную область. */
    public void loadPage(String fxmlName) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/comicshop/ui/" + fxmlName));
            Node page = loader.load();
            rootPane.setCenter(page);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** Загрузить каталог (комиксы/манга) и задать тип через CatalogController. */
    private void loadCatalog(String fxmlName, BookType type) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/comicshop/ui/" + fxmlName));
            Node page = loader.load();
            CatalogController controller = loader.getController();
            if (controller != null) {
                controller.setType(type);
            }
            rootPane.setCenter(page);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ===================== Статус =====================

    /** Обновляет надписи статуса корзины и пользователя в сайдбаре. */
    public void updateStatus() {
        CartService cart = CartService.getInstance();
        if (cartStatusLabel != null) {
            cartStatusLabel.setText(cart.isEmpty()
                    ? "Корзина: пуста"
                    : "Корзина: " + cart.getItemCount() + " шт.");
        }

        DataStore store = DataStore.getInstance();
        if (userStatusLabel != null) {
            userStatusLabel.setText(store.isLoggedIn()
                    ? "👤 " + store.getCurrentUser().getName()
                    : "Гость");
        }
    }
}
