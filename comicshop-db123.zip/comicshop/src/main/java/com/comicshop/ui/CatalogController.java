package com.comicshop.ui;

import com.comicshop.data.DataStore;
import com.comicshop.model.Book;
import com.comicshop.model.Book.BookType;
import com.comicshop.service.CartService;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.List;

/**
 * Контроллер каталога. Один контроллер используется и для комиксов,
 * и для манги — нужный тип задаётся методом {@link #setType(BookType)}.
 * Карточки выводятся сеткой по 5 в ряд.
 */
public class CatalogController {

    private static final int COLUMNS = 5;

    @FXML private GridPane grid;       // сетка карточек
    @FXML private Label titleLabel;    // заголовок раздела

    private BookType type = BookType.COMIC;

    @FXML
    public void initialize() {
        render(); // по умолчанию — комиксы; MainController может переопределить тип
    }

    /** Задать тип товаров для отображения и перерисовать сетку. */
    public void setType(BookType type) {
        this.type = type;
        render();
    }

    /** Заполнить сетку карточками выбранного типа. */
    private void render() {
        if (grid == null) {
            return;
        }
        grid.getChildren().clear();

        if (titleLabel != null) {
            titleLabel.setText(type == BookType.COMIC ? "Комиксы" : "Манга");
        }

        DataStore store = DataStore.getInstance();
        List<Book> books = (type == BookType.COMIC) ? store.getComics() : store.getManga();

        int index = 0;
        for (Book book : books) {
            int row = index / COLUMNS;
            int col = index % COLUMNS;
            grid.add(createBookCard(book), col, row);
            index++;
        }
    }

    /** Карточка товара: обложка-заглушка, название, автор, цена, рейтинг, кнопка. */
    private VBox createBookCard(Book book) {
        VBox card = new VBox(6);
        card.getStyleClass().add("book-card");
        card.setPadding(new Insets(12));
        card.setPrefWidth(200);

        Region cover = new Region();
        cover.getStyleClass().add("book-cover");
        cover.setPrefSize(176, 220);

        Label title = new Label(book.getTitle());
        title.setWrapText(true);
        title.setStyle("-fx-font-weight: bold;");

        Label author = new Label(book.getAuthor());

        Label price = new Label(String.format("%.0f ₽", book.getPrice()));
        price.getStyleClass().add("label-accent");

        Label rating = new Label("★ " + book.getRating() + "  (" + book.getReviewCount() + ")");

        Button addBtn = new Button("В корзину");
        addBtn.getStyleClass().add("button-primary");
        addBtn.setOnAction(e -> {
            CartService.getInstance().addBook(book, 1);
            if (MainController.getInstance() != null) {
                MainController.getInstance().updateStatus();
            }
        });

        card.getChildren().addAll(cover, title, author, price, rating, addBtn);
        return card;
    }
}
