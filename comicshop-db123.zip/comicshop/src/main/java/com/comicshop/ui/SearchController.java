package com.comicshop.ui;

import com.comicshop.data.DataStore;
import com.comicshop.model.Book;
import com.comicshop.service.CartService;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.List;

/**
 * Контроллер поиска. Вызывает DataStore.search() и выводит результаты;
 * при пустом результате показывает «Ничего не найдено».
 */
public class SearchController {

    @FXML private TextField searchField; // подсказка: "Введите название, автора или жанр..."
    @FXML private FlowPane resultsBox;    // контейнер результатов
    @FXML private Label messageLabel;     // сообщение ("Ничего не найдено")

    /** Привязка onAction к кнопке «Поиск» и к Enter в поле. */
    @FXML
    public void onSearch() {
        if (resultsBox == null) {
            return;
        }
        resultsBox.getChildren().clear();
        if (messageLabel != null) {
            messageLabel.setText("");
        }

        String query = searchField != null ? searchField.getText() : "";
        List<Book> results = DataStore.getInstance().search(query);

        if (results.isEmpty()) {
            if (messageLabel != null) {
                messageLabel.setText("Ничего не найдено");
            }
            return;
        }

        for (Book book : results) {
            resultsBox.getChildren().add(createBookCard(book));
        }
    }

    private VBox createBookCard(Book book) {
        VBox card = new VBox(6);
        card.getStyleClass().add("book-card");
        card.setPadding(new Insets(12));
        card.setPrefWidth(200);

        Region cover = new Region();
        cover.getStyleClass().add("book-cover");
        cover.setPrefSize(176, 220);

        Label title = new Label(book.getTitle());
        title.setWrapText(true);
        title.setStyle("-fx-font-weight: bold;");

        Label author = new Label(book.getAuthor());
        Label genre = new Label(book.getGenre() + " · " + book.getType().getDisplayName());

        Label price = new Label(String.format("%.0f ₽", book.getPrice()));
        price.getStyleClass().add("label-accent");

        Button addBtn = new Button("В корзину");
        addBtn.getStyleClass().add("button-primary");
        addBtn.setOnAction(e -> {
            CartService.getInstance().addBook(book, 1);
            if (MainController.getInstance() != null) {
                MainController.getInstance().updateStatus();
            }
        });

        card.getChildren().addAll(cover, title, author, genre, price, addBtn);
        return card;
    }
}
