package com.comicshop.ui;

import com.comicshop.data.DataStore;
import com.comicshop.db.DbException;
import com.comicshop.model.CartItem;
import com.comicshop.model.Order;
import com.comicshop.model.User;
import com.comicshop.service.CartService;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.ArrayList;

/**
 * Контроллер корзины: список товаров, изменение количества (+ / − / ✕),
 * итоговая сумма и оформление заказа.
 */
public class CartController {

    @FXML private VBox itemsBox;       // список позиций
    @FXML private Label totalLabel;    // итоговая сумма
    @FXML private Label emptyLabel;    // сообщение о пустой корзине
    @FXML private TextField addressField;
    @FXML private TextField phoneField;

    private final CartService cart = CartService.getInstance();

    @FXML
    public void initialize() {
        // Подставляем данные пользователя, если выполнен вход
        User user = DataStore.getInstance().getCurrentUser();
        if (user != null) {
            if (addressField != null && (addressField.getText() == null || addressField.getText().isBlank())) {
                addressField.setText(user.getAddress());
            }
            if (phoneField != null && (phoneField.getText() == null || phoneField.getText().isBlank())) {
                phoneField.setText(user.getPhone());
            }
        }
        render();
    }

    /** Перерисовать список корзины и сумму. */
    private void render() {
        if (itemsBox == null) {
            return;
        }
        itemsBox.getChildren().clear();

        if (cart.isEmpty()) {
            if (emptyLabel != null) {
                emptyLabel.setText("Корзина пуста");
            }
        } else {
            if (emptyLabel != null) {
                emptyLabel.setText("");
            }
            for (CartItem item : cart.getItems()) {
                itemsBox.getChildren().add(createRow(item));
            }
        }

        if (totalLabel != null) {
            totalLabel.setText(String.format("Итого: %.0f ₽", cart.getTotal()));
        }
        if (MainController.getInstance() != null) {
            MainController.getInstance().updateStatus();
        }
    }

    /** Строка корзины с кнопками −, +, ✕. */
    private HBox createRow(CartItem item) {
        HBox row = new HBox(10);
        row.getStyleClass().add("cart-row");
        row.setPadding(new Insets(10));
        row.setAlignment(Pos.CENTER_LEFT);

        VBox info = new VBox(2);
        Label title = new Label(item.getBook().getTitle());
        title.setStyle("-fx-font-weight: bold;");
        Label price = new Label(String.format("%.0f ₽ × %d", item.getBook().getPrice(), item.getQuantity()));
        info.getChildren().addAll(title, price);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        int bookId = item.getBook().getId();

        Button minus = new Button("−");
        minus.getStyleClass().add("nav-button");
        minus.setOnAction(e -> {
            cart.changeQuantity(bookId, item.getQuantity() - 1);
            render();
        });

        Label qty = new Label(String.valueOf(item.getQuantity()));
        qty.setMinWidth(28);
        qty.setAlignment(Pos.CENTER);

        Button plus = new Button("+");
        plus.getStyleClass().add("nav-button");
        plus.setOnAction(e -> {
            cart.changeQuantity(bookId, item.getQuantity() + 1);
            render();
        });

        Label sum = new Label(String.format("%.0f ₽", item.getTotalPrice()));
        sum.getStyleClass().add("label-accent");
        sum.setMinWidth(90);
        sum.setAlignment(Pos.CENTER_RIGHT);

        Button remove = new Button("✕");
        remove.getStyleClass().add("nav-button");
        remove.setOnAction(e -> {
            cart.removeBook(bookId);
            render();
        });

        row.getChildren().addAll(info, spacer, minus, qty, plus, sum, remove);
        return row;
    }

    /** Оформление заказа: проверка корзины и адреса/телефона. */
    @FXML
    public void onCheckout() {
        if (cart.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Корзина пуста", "Добавьте товары перед оформлением заказа.");
            return;
        }

        String address = addressField != null ? addressField.getText() : "";
        String phone = phoneField != null ? phoneField.getText() : "";

        if (address == null || address.isBlank() || phone == null || phone.isBlank()) {
            showAlert(Alert.AlertType.WARNING, "Заполните данные", "Укажите адрес доставки и телефон.");
            return;
        }

        User user = DataStore.getInstance().getCurrentUser();
        String name = (user != null) ? user.getName() : "Гость";
        String email = (user != null) ? user.getEmail() : "";

        Order order = new Order(name, email, phone, address, new ArrayList<>(cart.getItems()));
        int orderId;
        try {
            orderId = DataStore.getInstance().saveOrder(order);
        } catch (DbException ex) {
            System.err.println("[DB] " + ex.getMessage());
            showAlert(Alert.AlertType.ERROR, "Не удалось оформить заказ",
                    ex.getUserMessage() + "\nКорзина сохранена, заказ не создан.");
            return;
        }
        cart.clear();
        render();

        showAlert(Alert.AlertType.INFORMATION, "Заказ оформлен",
                "Заказ №" + orderId + " создан.\n"
                        + "Статус: " + order.getStatus().getDisplayName() + "\n"
                        + String.format("Сумма: %.0f ₽", order.getTotalAmount()));
    }

    private void showAlert(Alert.AlertType type, String header, String content) {
        Alert alert = new Alert(type);
        alert.setTitle("ComicShop");
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
