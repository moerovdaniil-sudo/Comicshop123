package com.comicshop.service;

import com.comicshop.model.Book;
import com.comicshop.model.CartItem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Сервис корзины (паттерн Singleton).
 */
public class CartService {

    private static CartService instance;

    private final List<CartItem> items = new ArrayList<>();

    private CartService() {
    }

    public static synchronized CartService getInstance() {
        if (instance == null) {
            instance = new CartService();
        }
        return instance;
    }

    /**
     * Добавить товар. Если он уже есть в корзине — увеличить количество,
     * иначе — добавить новую позицию.
     */
    public void addBook(Book book, int qty) {
        if (book == null || qty <= 0) {
            return;
        }
        for (CartItem item : items) {
            if (item.getBook().getId() == book.getId()) {
                item.setQuantity(item.getQuantity() + qty);
                return;
            }
        }
        items.add(new CartItem(book, qty));
    }

    /** Удалить позицию по id товара. */
    public void removeBook(int bookId) {
        items.removeIf(item -> item.getBook().getId() == bookId);
    }

    /**
     * Изменить количество. При qty <= 0 позиция удаляется.
     */
    public void changeQuantity(int bookId, int qty) {
        if (qty <= 0) {
            removeBook(bookId);
            return;
        }
        for (CartItem item : items) {
            if (item.getBook().getId() == bookId) {
                item.setQuantity(qty);
                return;
            }
        }
    }

    /** Немодифицируемый список позиций корзины. */
    public List<CartItem> getItems() {
        return Collections.unmodifiableList(items);
    }

    /** Итоговая сумма корзины. */
    public double getTotal() {
        return items.stream().mapToDouble(CartItem::getTotalPrice).sum();
    }

    /** Суммарное количество единиц товара в корзине. */
    public int getItemCount() {
        return items.stream().mapToInt(CartItem::getQuantity).sum();
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public void clear() {
        items.clear();
    }
}
