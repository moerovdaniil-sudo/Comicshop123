package com.comicshop.db;

import com.comicshop.model.Book;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

/**
 * Проверка подключения к БД и модуля доступа. Запуск: метод main в IntelliJ IDEA
 * (или mvn exec:java -Dexec.mainClass=com.comicshop.db.DbCheck). Данные в БД не изменяются.
 */
public class DbCheck {

    private static final String[] TABLES = {"categories", "products", "orders", "order_items", "employees",
            "addresses", "suppliers", "warehouses", "supplies", "reviews"};

    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        System.out.println("=== Проверка модуля доступа к БД ComicShop ===");
        Database db;
        try {
            db = Database.getInstance();
            String version = db.query(c -> {
                try (PreparedStatement ps = c.prepareStatement("SELECT version()");
                     ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    return rs.getString(1);
                }
            });
            check("DB-01 Подключение к БД", true, version);
        } catch (RuntimeException e) {
            check("DB-01 Подключение к БД", false, e.getMessage());
            summary();
            return;
        }

        for (String t : TABLES) {
            try {
                long n = count(db, t);
                check("DB-02 Таблица " + t + " доступна", true, n + " строк");
            } catch (RuntimeException e) {
                check("DB-02 Таблица " + t + " доступна", false, e.getMessage());
            }
        }

        CatalogDao catalog = new CatalogDao(db);
        try {
            List<Book> all = catalog.findAll();
            check("DB-03 Загрузка каталога (products + categories)", !all.isEmpty(), all.size() + " товаров");
            long before = count(db, "products");

            String q = all.isEmpty() ? "а" : all.get(0).getTitle().substring(0, 1).toLowerCase();
            List<Book> found = catalog.search(q);
            check("DB-04 Поиск без учёта регистра по «" + q + "»", !found.isEmpty(), found.size() + " товаров");

            for (String evil : new String[]{"%", "' OR '1'='1", "'; DROP TABLE products; --"}) {
                List<Book> r = catalog.search(evil);
                boolean ok = r.size() < all.size() && count(db, "products") == before;
                check("DB-05 Ввод «" + evil + "» трактуется как текст", ok,
                        "найдено " + r.size() + ", в products строк: " + count(db, "products"));
            }
        } catch (RuntimeException e) {
            check("DB-03..05 Каталог и поиск", false, e.getMessage());
        }

        try {
            String bad = "SELEC * FROM products";
            db.query(c -> {
                try (PreparedStatement ps = c.prepareStatement(bad)) {
                    ps.execute();
                    return null;
                }
            });
            check("DB-06 Синтаксическая ошибка перехватывается", false, "ошибка не возникла");
        } catch (DbException e) {
            check("DB-06 Синтаксическая ошибка перехватывается", e.getKind() == DbException.Kind.SYNTAX,
                    e.getKind() + " [" + e.getSqlState() + "]");
        }
        summary();
    }

    private static long count(Database db, String table) {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM " + table);
                 ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getLong(1);
            }
        });
    }

    private static void check(String name, boolean ok, String details) {
        if (ok) passed++; else failed++;
        System.out.printf("%s  %s — %s%n", ok ? "PASS" : "FAIL", name, details);
    }

    private static void summary() {
        System.out.println("ИТОГО: PASS=" + passed + ", FAIL=" + failed);
    }
}
