package com.comicshop.db;

import com.comicshop.model.Book;
import com.comicshop.model.Book.BookType;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * Каталог товаров: чтение таблиц products и categories (рейтинг и число отзывов берутся из reviews).
 * Структура таблиц БД не изменяется. Все запросы — PreparedStatement.
 */
public class CatalogDao {

    private static final String SELECT_BOOK =
            "SELECT p.id, p.name, p.price, p.quantity, p.description, c.name AS category, "
                    + "COALESCE((SELECT ROUND(AVG(r.rating)::numeric, 1) FROM reviews r WHERE r.product_id = p.id), 0) AS rating, "
                    + "(SELECT COUNT(*) FROM reviews r WHERE r.product_id = p.id) AS review_count "
                    + "FROM products p LEFT JOIN categories c ON c.id = p.category_id ";

    private final Database db;

    public CatalogDao(Database db) {
        this.db = db;
    }

    /** Весь каталог. */
    public List<Book> findAll() {
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(SELECT_BOOK + "ORDER BY p.id")) {
                ps.setQueryTimeout(db.getConfig().queryTimeoutSec);
                return readBooks(ps);
            }
        });
    }

    /** Поиск без учёта регистра по названию, категории и описанию. Ввод передаётся параметром. */
    public List<Book> search(String query) {
        String like = "%" + escapeLike(query.trim()) + "%";
        return db.query(c -> {
            try (PreparedStatement ps = c.prepareStatement(SELECT_BOOK
                    + "WHERE p.name ILIKE ? ESCAPE '\\' OR c.name ILIKE ? ESCAPE '\\' "
                    + "OR p.description ILIKE ? ESCAPE '\\' ORDER BY p.id")) {
                ps.setQueryTimeout(db.getConfig().queryTimeoutSec);
                ps.setString(1, like);
                ps.setString(2, like);
                ps.setString(3, like);
                return readBooks(ps);
            }
        });
    }

    /** Экранирование спецсимволов LIKE (%, _, \), чтобы они искались как обычный текст. */
    static String escapeLike(String s) {
        return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }

    private static List<Book> readBooks(PreparedStatement ps) throws java.sql.SQLException {
        List<Book> list = new ArrayList<>();
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String category = rs.getString("category");
                BookType type = category != null && category.toLowerCase().contains("манг")
                        ? BookType.MANGA : BookType.COMIC;
                String description = rs.getString("description");
                list.add(new Book(rs.getInt("id"), rs.getString("name"), "—", "—",
                        category == null ? "Без категории" : category, type,
                        rs.getBigDecimal("price").doubleValue(), rs.getInt("quantity"),
                        description == null ? "" : description, false, false,
                        rs.getDouble("rating"), rs.getInt("review_count")));
            }
        }
        return list;
    }
}
