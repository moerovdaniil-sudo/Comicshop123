package com.comicshop.db;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Настройки подключения к БД.
 * Логин и пароль НЕ хранятся в коде: берутся из переменных окружения
 * COMICSHOP_DB_URL / COMICSHOP_DB_USER / COMICSHOP_DB_PASSWORD
 * либо из файла db.properties в рабочей папке (файл добавлен в .gitignore).
 */
public final class DbConfig {

    public final String url;
    public final String user;
    public final String password;
    public final int poolSize;
    public final long poolTimeoutMs;
    public final int connectTimeoutSec;
    public final int socketTimeoutSec;
    public final int queryTimeoutSec;
    public final int retryMax;
    public final long retryBaseDelayMs;

    private DbConfig(Properties p) {
        this.url = p.getProperty("db.url", "jdbc:postgresql://localhost:5432/comicshop");
        this.user = p.getProperty("db.user");
        this.password = p.getProperty("db.password");
        this.poolSize = Integer.parseInt(p.getProperty("pool.size", "5"));
        this.poolTimeoutMs = Long.parseLong(p.getProperty("pool.timeoutMs", "3000"));
        this.connectTimeoutSec = Integer.parseInt(p.getProperty("db.connectTimeoutSec", "5"));
        this.socketTimeoutSec = Integer.parseInt(p.getProperty("db.socketTimeoutSec", "30"));
        this.queryTimeoutSec = Integer.parseInt(p.getProperty("db.queryTimeoutSec", "10"));
        this.retryMax = Integer.parseInt(p.getProperty("retry.max", "3"));
        this.retryBaseDelayMs = Long.parseLong(p.getProperty("retry.baseDelayMs", "200"));
        if (user == null || password == null) {
            throw new IllegalStateException("Не заданы логин/пароль БД. Укажите переменные окружения "
                    + "COMICSHOP_DB_USER и COMICSHOP_DB_PASSWORD или создайте файл db.properties "
                    + "(образец: db.properties.example).");
        }
    }

    /** Создать конфигурацию из явных значений (используется в тестах). */
    public static DbConfig of(Properties overrides) {
        return new DbConfig(overrides);
    }

    /** Загрузить конфигурацию: db.properties, затем переменные окружения (приоритетнее). */
    public static DbConfig load() {
        Properties p = new Properties();
        Path file = Path.of("db.properties");
        if (Files.exists(file)) {
            try (InputStream in = Files.newInputStream(file)) {
                p.load(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8));
            } catch (IOException e) {
                throw new IllegalStateException("Не удалось прочитать db.properties: " + e.getMessage(), e);
            }
        }
        putEnv(p, "COMICSHOP_DB_URL", "db.url");
        putEnv(p, "COMICSHOP_DB_USER", "db.user");
        putEnv(p, "COMICSHOP_DB_PASSWORD", "db.password");
        return new DbConfig(p);
    }

    private static void putEnv(Properties p, String env, String key) {
        String v = System.getenv(env);
        if (v != null && !v.isBlank()) {
            p.setProperty(key, v);
        }
    }
}
