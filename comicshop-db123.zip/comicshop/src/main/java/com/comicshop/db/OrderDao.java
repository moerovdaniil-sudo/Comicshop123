package com.comicshop.db;

import com.comicshop.model.CartItem;
import com.comicshop.model.Order;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

/** Сохранение заказа в таблицы orders и order_items (структура таблиц не меняется). */
public class OrderDao {

    private final Database db;

    public OrderDao(Database db) {
        this.db = db;
    }

    /**
     * Сохраняет заказ ОДНОЙ транзакцией: заказ, позиции и списание остатка в products.quantity.
     * При нехватке товара или отсутствии товара в каталоге откатывается всё. Возвращает номер заказа из БД.
     */
    public int create(Order order) {
        return db.inTransaction(c -> {
            int orderId;
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO orders DEFAULT VALUES RETURNING id")) {
                ps.setQueryTimeout(db.getConfig().queryTimeoutSec);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    orderId = rs.getInt(1);
                }
            }
            for (CartItem item : order.getItems()) {
                int bookId = item.getBook().getId();
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE products SET quantity = quantity - ? WHERE id = ? AND quantity >= ?")) {
                    ps.setQueryTimeout(db.getConfig().queryTimeoutSec);
                    ps.setInt(1, item.getQuantity());
                    ps.setInt(2, bookId);
                    ps.setInt(3, item.getQuantity());
                    if (ps.executeUpdate() == 0) {
                        throw new DbException(exists(c, bookId) ? DbException.Kind.OUT_OF_STOCK
                                : DbException.Kind.NOT_FOUND, "Товар id=" + bookId + ": недостаточно на складе или нет в каталоге");
                    }
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO order_items(order_id, product_id, quantity) VALUES (?,?,?)")) {
                    ps.setQueryTimeout(db.getConfig().queryTimeoutSec);
                    ps.setInt(1, orderId);
                    ps.setInt(2, bookId);
                    ps.setInt(3, item.getQuantity());
                    ps.executeUpdate();
                }
            }
            return orderId;
        });
    }

    private boolean exists(java.sql.Connection c, int productId) throws java.sql.SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT 1 FROM products WHERE id = ?")) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
}
