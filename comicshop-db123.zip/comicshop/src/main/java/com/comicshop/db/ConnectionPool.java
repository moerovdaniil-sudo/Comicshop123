package com.comicshop.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Небольшой пул соединений с ограничением размера и таймаутом ожидания.
 * Если все соединения заняты дольше pool.timeoutMs — бросается DbException(POOL_EXHAUSTED).
 */
public final class ConnectionPool implements AutoCloseable {

    private final DbConfig cfg;
    private final Semaphore permits;
    private final BlockingQueue<Connection> idle;
    private volatile boolean closed;

    public ConnectionPool(DbConfig cfg) {
        this.cfg = cfg;
        this.permits = new Semaphore(cfg.poolSize, true);
        this.idle = new ArrayBlockingQueue<>(cfg.poolSize);
    }

    /** Взять соединение из пула (или открыть новое). Обязательно вернуть через release(). */
    public Connection acquire() {
        if (closed) {
            throw new DbException(DbException.Kind.OTHER, "Пул соединений закрыт");
        }
        try {
            if (!permits.tryAcquire(cfg.poolTimeoutMs, TimeUnit.MILLISECONDS)) {
                throw new DbException(DbException.Kind.POOL_EXHAUSTED,
                        "Нет свободных соединений за " + cfg.poolTimeoutMs + " мс (размер пула " + cfg.poolSize + ")");
            }
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new DbException(DbException.Kind.OTHER, "Ожидание соединения прервано", ie);
        }
        try {
            Connection c;
            while ((c = idle.poll()) != null) {
                if (isAlive(c)) {
                    return c;
                }
                closeQuietly(c);               // «мёртвое» соединение выбрасываем
            }
            return open();
        } catch (SQLException e) {
            permits.release();
            throw DbException.from(e);
        } catch (RuntimeException e) {
            permits.release();
            throw e;
        }
    }

    /** Вернуть соединение в пул. Если оно сломано — закрывается и не возвращается. */
    public void release(Connection c) {
        if (c == null) {
            return;
        }
        try {
            if (!closed && !c.isClosed() && isAlive(c)) {
                if (!c.getAutoCommit()) {
                    c.rollback();
                    c.setAutoCommit(true);
                }
                if (idle.offer(c)) {
                    return;
                }
            }
            closeQuietly(c);
        } catch (SQLException e) {
            closeQuietly(c);
        } finally {
            permits.release();
        }
    }

    private Connection open() throws SQLException {
        Properties p = new Properties();
        p.setProperty("user", cfg.user);
        p.setProperty("password", cfg.password);
        p.setProperty("connectTimeout", String.valueOf(cfg.connectTimeoutSec));
        p.setProperty("socketTimeout", String.valueOf(cfg.socketTimeoutSec));
        p.setProperty("ApplicationName", "ComicShop");
        Connection c = DriverManager.getConnection(cfg.url, p);
        c.setAutoCommit(true);
        return c;
    }

    private boolean isAlive(Connection c) {
        try {
            return !c.isClosed() && c.isValid(2);
        } catch (SQLException e) {
            return false;
        }
    }

    private void closeQuietly(Connection c) {
        try {
            c.close();
        } catch (SQLException ignored) {
            // нечего делать
        }
    }

    public int availablePermits() {
        return permits.availablePermits();
    }

    @Override
    public void close() {
        closed = true;
        Connection c;
        while ((c = idle.poll()) != null) {
            closeQuietly(c);
        }
    }
}
