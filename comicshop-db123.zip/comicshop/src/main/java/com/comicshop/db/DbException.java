package com.comicshop.db;

import java.sql.SQLException;

/**
 * Единое исключение слоя доступа к БД. Превращает «сырые» SQLException
 * (по коду SQLState) в понятные категории ошибок.
 */
public class DbException extends RuntimeException {

    /** Категория ошибки. */
    public enum Kind {
        CONNECTION("Нет связи с базой данных. Проверьте подключение и повторите попытку."),
        POOL_EXHAUSTED("Сервер перегружен: все соединения заняты. Повторите попытку позже."),
        TIMEOUT("Превышено время ожидания ответа от базы данных."),
        DUPLICATE("Такая запись уже существует."),
        FOREIGN_KEY("Операция нарушает связь между данными (запись не найдена или используется)."),
        NOT_NULL("Не заполнено обязательное поле."),
        TOO_LONG("Значение слишком длинное для этого поля."),
        CHECK("Значение не прошло проверку допустимости."),
        OUT_OF_STOCK("Недостаточно товара на складе."),
        CONCURRENT_MODIFICATION("Данные были изменены другим пользователем. Обновите страницу и повторите."),
        DEADLOCK("Конфликт одновременных операций. Повторите попытку."),
        SYNTAX("Внутренняя ошибка: некорректный SQL-запрос."),
        NOT_FOUND("Запись не найдена."),
        OTHER("Ошибка при работе с базой данных.");

        private final String userMessage;

        Kind(String userMessage) {
            this.userMessage = userMessage;
        }

        public String getUserMessage() {
            return userMessage;
        }
    }

    private final Kind kind;
    private final String sqlState;

    public DbException(Kind kind, String message, Throwable cause) {
        super(message, cause);
        this.kind = kind;
        this.sqlState = (cause instanceof SQLException) ? ((SQLException) cause).getSQLState() : null;
    }

    public DbException(Kind kind, String message) {
        this(kind, message, null);
    }

    public Kind getKind() {
        return kind;
    }

    public String getSqlState() {
        return sqlState;
    }

    /** Сообщение, безопасное для показа пользователю (без деталей SQL). */
    public String getUserMessage() {
        return kind.getUserMessage();
    }

    /** Ошибки, при которых имеет смысл повторить операцию. */
    public boolean isTransient() {
        return kind == Kind.CONNECTION || kind == Kind.DEADLOCK;
    }

    /** Преобразование SQLException в DbException по коду SQLState. */
    public static DbException from(SQLException e) {
        String s = e.getSQLState() == null ? "" : e.getSQLState();
        Kind k;
        if (s.startsWith("08") || s.equals("57P01") || s.equals("57P02") || s.equals("57P03")) {
            k = Kind.CONNECTION;                 // обрыв/недоступность соединения, остановка сервера
        } else if (s.equals("53300")) {
            k = Kind.POOL_EXHAUSTED;             // too_many_connections
        } else if (s.equals("57014")) {
            k = Kind.TIMEOUT;                    // query_canceled (statement_timeout / setQueryTimeout)
        } else if (s.equals("23505")) {
            k = Kind.DUPLICATE;                  // unique_violation
        } else if (s.equals("23503")) {
            k = Kind.FOREIGN_KEY;                // foreign_key_violation
        } else if (s.equals("23502")) {
            k = Kind.NOT_NULL;                   // not_null_violation
        } else if (s.equals("22001")) {
            k = Kind.TOO_LONG;                   // string_data_right_truncation
        } else if (s.equals("23514") || s.startsWith("22")) {
            k = Kind.CHECK;                      // check_violation / ошибки данных (22003, 22P02 ...)
        } else if (s.equals("CS001")) {
            k = Kind.OUT_OF_STOCK;               // собственный код триггера
        } else if (s.equals("40P01") || s.equals("40001")) {
            k = Kind.DEADLOCK;                   // deadlock_detected / serialization_failure
        } else if (s.startsWith("42")) {
            k = Kind.SYNTAX;                     // синтаксис, неизвестная таблица/колонка
        } else if (e instanceof java.sql.SQLTimeoutException) {
            k = Kind.TIMEOUT;
        } else {
            k = Kind.OTHER;
        }
        return new DbException(k, k + " [SQLState=" + s + "]: " + e.getMessage(), e);
    }
}
