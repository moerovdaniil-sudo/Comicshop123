package com.comicshop.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.function.Consumer;

/**
 * Точка доступа к БД: выдаёт соединение из пула, выполняет действие,
 * преобразует SQLException в DbException и повторяет операцию при потере связи (retry).
 */
public final class Database {

    private static Database instance;

    private final DbConfig cfg;
    private final ConnectionPool pool;
    private Consumer<String> log = msg -> System.err.println("[DB] " + msg);

    public Database(DbConfig cfg) {
        this.cfg = cfg;
        this.pool = new ConnectionPool(cfg);
    }

    public static synchronized Database getInstance() {
        if (instance == null) {
            instance = new Database(DbConfig.load());
        }
        return instance;
    }

    public DbConfig getConfig() {
        return cfg;
    }

    public ConnectionPool getPool() {
        return pool;
    }

    public void setLogger(Consumer<String> logger) {
        this.log = logger;
    }

    /** Выполнить чтение/одиночную операцию (auto-commit) с повторами при сбое связи. */
    public <T> T query(SqlFunction<T> work) {
        return run(work, false);
    }

    /**
     * Выполнить работу в одной транзакции: COMMIT при успехе, ROLLBACK при любой ошибке.
     * При потере связи вся транзакция выполняется заново с самого начала.
     */
    public <T> T inTransaction(SqlFunction<T> work) {
        return run(work, true);
    }

    private <T> T run(SqlFunction<T> work, boolean transactional) {
        int attempt = 0;
        while (true) {
            attempt++;
            Connection c = null;
            try {
                c = pool.acquire();
                if (transactional) {
                    c.setAutoCommit(false);
                }
                T result = work.apply(c);
                if (transactional) {
                    c.commit();
                }
                return result;
            } catch (SQLException e) {
                rollbackQuietly(c, transactional);
                DbException de = DbException.from(e);
                if (!shouldRetry(de, attempt)) {
                    throw de;
                }
                pause(de, attempt);
            } catch (DbException e) {
                rollbackQuietly(c, transactional);
                if (!shouldRetry(e, attempt)) {
                    throw e;
                }
                pause(e, attempt);
            } catch (RuntimeException e) {
                rollbackQuietly(c, transactional);
                throw e;
            } finally {
                pool.release(c);
            }
        }
    }

    private boolean shouldRetry(DbException e, int attempt) {
        return e.isTransient() && attempt <= cfg.retryMax;
    }

    /** Экспоненциальная пауза: base, 2*base, 4*base... */
    private void pause(DbException e, int attempt) {
        long delay = cfg.retryBaseDelayMs * (1L << (attempt - 1));
        log.accept("Попытка " + attempt + " не удалась (" + e.getKind() + "). Повтор через " + delay + " мс");
        try {
            Thread.sleep(delay);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new DbException(DbException.Kind.OTHER, "Повтор операции прерван", ie);
        }
    }

    private void rollbackQuietly(Connection c, boolean transactional) {
        if (c != null && transactional) {
            try {
                c.rollback();
            } catch (SQLException ignored) {
                // соединение уже разорвано — пул его выбросит
            }
        }
    }
}
