package com.comicshop.db;

import java.sql.Connection;
import java.sql.SQLException;

/** Действие над соединением с БД; может бросать SQLException. */
@FunctionalInterface
public interface SqlFunction<T> {
    T apply(Connection c) throws SQLException;
}
