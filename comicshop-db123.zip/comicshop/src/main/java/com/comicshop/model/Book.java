package com.comicshop.model;

/**
 * Модель товара магазина — комикс или манга.
 */
public class Book {

    /** Тип товара с русским отображаемым названием. */
    public enum BookType {
        COMIC("Комикс"),
        MANGA("Манга");

        private final String displayName;

        BookType(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    private int id;
    private String title;
    private String author;
    private String publisher;
    private String genre;
    private BookType type;
    private double price;
    private int stock;
    private String description;
    private boolean isNew;
    private boolean isPopular;
    private double rating;
    private int reviewCount;

    public Book() {
    }

    public Book(int id, String title, String author, String publisher, String genre,
                BookType type, double price, int stock, String description,
                boolean isNew, boolean isPopular, double rating, int reviewCount) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.genre = genre;
        this.type = type;
        this.price = price;
        this.stock = stock;
        this.description = description;
        this.isNew = isNew;
        this.isPopular = isPopular;
        this.rating = rating;
        this.reviewCount = reviewCount;
    }

    // --- Геттеры / сеттеры ---

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public BookType getType() {
        return type;
    }

    public void setType(BookType type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isNew() {
        return isNew;
    }

    public void setNew(boolean aNew) {
        isNew = aNew;
    }

    public boolean isPopular() {
        return isPopular;
    }

    public void setPopular(boolean popular) {
        isPopular = popular;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public int getReviewCount() {
        return reviewCount;
    }

    public void setReviewCount(int reviewCount) {
        this.reviewCount = reviewCount;
    }

    @Override
    public String toString() {
        return title + " — " + author + " (" + String.format("%.0f", price) + " ₽)";
    }
}
