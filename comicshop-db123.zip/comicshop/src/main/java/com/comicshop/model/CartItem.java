package com.comicshop.model;

/**
 * Позиция корзины: товар + количество.
 */
public class CartItem {

    private Book book;
    private int quantity;

    public CartItem(Book book, int quantity) {
        this.book = book;
        this.quantity = quantity;
    }

    /** Стоимость позиции = цена * количество. */
    public double getTotalPrice() {
        return book.getPrice() * quantity;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
