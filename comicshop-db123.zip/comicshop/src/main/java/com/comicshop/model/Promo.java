package com.comicshop.model;

/**
 * Акция магазина: название, процент скидки, описание.
 */
public class Promo {

    private String title;
    private int discountPercent;
    private String description;

    public Promo(String title, int discountPercent, String description) {
        this.title = title;
        this.discountPercent = discountPercent;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(int discountPercent) {
        this.discountPercent = discountPercent;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
