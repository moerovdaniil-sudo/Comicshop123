package com.comicshop.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Заказ. Номер генерируется автоматически, начиная с 1000.
 */
public class Order {

    /** Глобальный счётчик номеров заказов. */
    private static int counter = 1000;

    /** Способ доставки. */
    public enum DeliveryMethod {
        COURIER("Курьером"),
        PICKUP("Самовывоз"),
        MAIL("Почта России");

        private final String displayName;

        DeliveryMethod(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    /** Способ оплаты. */
    public enum PaymentMethod {
        CARD("Банковская карта"),
        CASH("Наличными при получении"),
        ONLINE("Онлайн-оплата");

        private final String displayName;

        PaymentMethod(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    /** Статус заказа. */
    public enum OrderStatus {
        CREATED("Заказ создан"),
        PROCESSING("Обработка заказа"),
        SHIPPING("Доставка"),
        DELIVERED("Заказ выполнен");

        private final String displayName;

        OrderStatus(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    private final int id;
    private String userName;
    private String email;
    private String phone;
    private String address;
    private DeliveryMethod deliveryMethod;
    private PaymentMethod paymentMethod;
    private OrderStatus status;
    private final List<CartItem> items;
    private final LocalDateTime createdAt;
    private double totalAmount;

    /**
     * Создаёт заказ. Номер, дата и статус выставляются автоматически.
     * Сумма считается по переданным позициям корзины.
     */
    public Order(String userName, String email, String phone, String address, List<CartItem> items) {
        this.id = counter++;
        this.userName = userName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.items = new ArrayList<>(items);
        this.createdAt = LocalDateTime.now();
        this.status = OrderStatus.CREATED;
        this.deliveryMethod = DeliveryMethod.COURIER;
        this.paymentMethod = PaymentMethod.CARD;
        this.totalAmount = items.stream().mapToDouble(CartItem::getTotalPrice).sum();
    }

    public int getId() {
        return id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public DeliveryMethod getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(DeliveryMethod deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public List<CartItem> getItems() {
        return items;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }
}
