package com.comicshop;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Точка входа приложения ComicShop.
 * Загружает главное окно main.fxml и подключает стили.
 */
public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        // Загрузка корневого FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/comicshop/ui/main.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root, 1280, 800);
        // Подключение CSS-стилей (тёмная тема)
        scene.getStylesheets().add(getClass().getResource("/com/comicshop/ui/styles.css").toExternalForm());

        stage.setTitle("ComicShop — Магазин комиксов и манги");
        stage.setScene(scene);
        stage.setMinWidth(800);
        stage.setMinHeight(600);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
