package com.comicshop.data;

import com.comicshop.db.CatalogDao;
import com.comicshop.db.Database;
import com.comicshop.db.DbException;
import com.comicshop.db.OrderDao;
import com.comicshop.model.Book;
import com.comicshop.model.Book.BookType;
import com.comicshop.model.Order;
import com.comicshop.model.Promo;
import com.comicshop.model.User;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Хранилище данных приложения (паттерн Singleton).
 * Каталог и заказы работают с БД PostgreSQL (пакет com.comicshop.db). Если БД недоступна или не заданы
 * логин и пароль (db.properties), приложение работает на тестовых данных в памяти (резервный режим).
 * Вход и регистрация пользователей хранятся в памяти: в схеме БД нет таблицы пользователей.
 */
public class DataStore {

    private static DataStore instance;

    private final List<Book> books = new ArrayList<>();
    private final List<Promo> promos = new ArrayList<>();
    private final List<User> users = new ArrayList<>();

    private User currentUser; // null, если не выполнен вход

    private int bookIdCounter = 1;

    private CatalogDao catalogDao;
    private OrderDao orderDao;
    private boolean dbMode;

    private DataStore() {
        initBooks();
        initPromos();
        initDemoUser();
        connectToDb();
    }

    /** Подключение к БД. При любой ошибке остаёмся на данных в памяти. */
    private void connectToDb() {
        try {
            Database db = Database.getInstance();
            catalogDao = new CatalogDao(db);
            orderDao = new OrderDao(db);
            reloadCatalog();
            dbMode = true;
            System.err.println("[DB] Режим БД: загружено товаров " + books.size());
        } catch (RuntimeException e) {
            System.err.println("[DB] Резервный режим (данные в памяти): " + e.getMessage());
        }
    }

    /** Перечитать каталог из БД и определить «новинки» и «популярное» по данным. */
    private void reloadCatalog() {
        List<Book> loaded = catalogDao.findAll();
        if (loaded.isEmpty()) {
            throw new DbException(DbException.Kind.NOT_FOUND, "Таблица products пуста");
        }
        books.clear();
        books.addAll(loaded);
        books.stream().sorted((a, b) -> b.getReviewCount() != a.getReviewCount()
                        ? Integer.compare(b.getReviewCount(), a.getReviewCount())
                        : Double.compare(b.getRating(), a.getRating()))
                .limit(6).forEach(b -> b.setPopular(true));
        books.stream().sorted((a, b) -> Integer.compare(b.getId(), a.getId()))
                .limit(4).forEach(b -> b.setNew(true));
    }

    public boolean isDbMode() {
        return dbMode;
    }

    /**
     * Сохраняет заказ. В режиме БД — в таблицы orders/order_items одной транзакцией (при ошибке
     * бросается DbException, остатки не меняются); в резервном режиме возвращает номер заказа из памяти.
     */
    public int saveOrder(Order order) {
        if (!dbMode) {
            return order.getId();
        }
        int id = orderDao.create(order);
        try {
            reloadCatalog();   // обновить остатки
        } catch (RuntimeException e) {
            System.err.println("[DB] Не удалось обновить каталог: " + e.getMessage());
        }
        return id;
    }

    /** Получить единственный экземпляр хранилища. */
    public static synchronized DataStore getInstance() {
        if (instance == null) {
            instance = new DataStore();
        }
        return instance;
    }

    // ===================== Инициализация тестовых данных =====================

    private void addBook(String title, String author, String publisher, String genre,
                         BookType type, double price, int stock, String description,
                         boolean isNew, boolean isPopular, double rating, int reviewCount) {
        books.add(new Book(bookIdCounter++, title, author, publisher, genre, type,
                price, stock, description, isNew, isPopular, rating, reviewCount));
    }

    private void initBooks() {
        // --- Комиксы (минимум 12) ---
        addBook("Человек-Паук: Синий", "Джеф Лоэб", "Marvel", "Супергерои",
                BookType.COMIC, 890, 25, "Трогательная история о Питере Паркере и Гвен Стейси.",
                false, true, 4.8, 312);
        addBook("Бэтмен: Долгий Хэллоуин", "Джеф Лоэб", "DC Comics", "Детектив",
                BookType.COMIC, 1200, 18, "Тёмный детектив о Тёмном рыцаре и серийном убийце Празднике.",
                true, true, 4.9, 540);
        addBook("Бэтмен: Тихо", "Джеф Лоэб", "DC Comics", "Детектив",
                BookType.COMIC, 1350, 12, "Загадочный враг по имени Тихо плетёт интриги против Бэтмена.",
                false, true, 4.7, 287);
        addBook("Человек-Паук: Возвращение домой", "Дэн Слотт", "Marvel", "Супергерои",
                BookType.COMIC, 950, 20, "Новые приключения дружелюбного соседа.",
                false, false, 4.5, 198);
        addBook("Дэдпул: Начало", "Фабиан Нисиеза", "Marvel", "Боевик",
                BookType.COMIC, 780, 30, "Безбашенный наёмник Уэйд Уилсон во всей красе.",
                false, true, 4.6, 421);
        addBook("Хранители", "Алан Мур", "DC Comics", "Драма",
                BookType.COMIC, 1500, 10, "Легендарный графический роман о супергероях вне закона.",
                false, true, 4.9, 890);
        addBook("Сорвиголова: Рождённый заново", "Фрэнк Миллер", "Marvel", "Супергерои",
                BookType.COMIC, 1100, 14, "Мэтт Мёрдок теряет всё и начинает с нуля.",
                false, false, 4.7, 256);
        addBook("Супермен: Красный сын", "Марк Миллар", "DC Comics", "Фантастика",
                BookType.COMIC, 1050, 16, "Что если Супермен приземлился бы в СССР?",
                true, false, 4.6, 333);
        addBook("Тор: Бог Грома", "Джейсон Аарон", "Marvel", "Фэнтези",
                BookType.COMIC, 920, 22, "Тор сражается с Богоубийцей сквозь эпохи.",
                false, false, 4.4, 175);
        addBook("Лига Справедливости: Начало", "Джефф Джонс", "DC Comics", "Супергерои",
                BookType.COMIC, 990, 19, "Рождение величайшей команды героев.",
                false, false, 4.5, 210);
        addBook("Веном: Первый хозяин", "Донни Кейтс", "Marvel", "Боевик",
                BookType.COMIC, 860, 27, "Происхождение симбиота и его связь с Эдди Броком.",
                true, false, 4.3, 144);
        addBook("Зелёный Фонарь", "Джефф Джонс", "DC Comics", "Фантастика",
                BookType.COMIC, 870, 21, "Хэл Джордан и Корпус Зелёных Фонарей.",
                false, false, 4.2, 132);
        addBook("Капитан Америка: Зимний солдат", "Эд Брубейкер", "Marvel", "Боевик",
                BookType.COMIC, 1080, 17, "Возвращение Баки Барнса как Зимнего солдата.",
                false, true, 4.7, 398);

        // --- Манга (минимум 7) ---
        addBook("Тетрадь смерти. Том 1", "Цугуми Ооба", "Азбука", "Триллер",
                BookType.MANGA, 650, 40, "Школьник находит тетрадь, способную убивать.",
                false, true, 4.9, 612);
        addBook("Наруто. Том 1", "Масаси Кисимото", "Эксмо", "Сёнэн",
                BookType.MANGA, 600, 50, "Юный ниндзя мечтает стать Хокаге.",
                false, true, 4.7, 705);
        addBook("Атака титанов. Том 1", "Хадзимэ Исаяма", "Эксмо", "Сёнэн",
                BookType.MANGA, 700, 35, "Человечество за стенами против гигантских титанов.",
                true, true, 4.8, 668);
        addBook("Ван-Пис. Том 1", "Эйитиро Ода", "Азбука", "Сёнэн",
                BookType.MANGA, 620, 45, "Луффи отправляется на поиски легендарного сокровища.",
                false, true, 4.8, 590);
        addBook("Берсерк. Том 1", "Кэнтаро Миура", "XL Media", "Тёмное фэнтези",
                BookType.MANGA, 950, 15, "Мрачное эпическое фэнтези о мечнике Гатсе.",
                false, false, 4.9, 480);
        addBook("Магическая битва. Том 1", "Гэгэ Акутами", "Азбука", "Сёнэн",
                BookType.MANGA, 680, 33, "Юдзи Итадори вступает в мир проклятий.",
                true, false, 4.6, 351);
        addBook("Клинок, рассекающий демонов. Том 1", "Коёхару Готогэ", "Истари", "Сёнэн",
                BookType.MANGA, 690, 38, "Тандзиро мстит демонам за свою семью.",
                false, true, 4.7, 522);
        addBook("Стальной алхимик. Том 1", "Хирому Аракава", "XL Media", "Сёнэн",
                BookType.MANGA, 720, 28, "Братья Элрик ищут философский камень.",
                false, false, 4.8, 460);
    }

    private void initPromos() {
        promos.add(new Promo("Новинки месяца", 15, "Скидка 15% на все новинки этого месяца."));
        promos.add(new Promo("Фан-неделя манги", 20, "Скидка 20% на всю мангу всю неделю."));
        promos.add(new Promo("Марвел vs DC", 10, "Скидка 10% на все комиксы Marvel и DC."));
    }

    private void initDemoUser() {
        users.add(new User("Иван Иванов", "ivan@mail.ru", "1234",
                "+7 900 000-00-00", "г. Энгельс, ул. Пушкина, д.1"));
    }

    // ===================== Доступ к данным =====================

    public List<Book> getBooks() {
        return Collections.unmodifiableList(books);
    }

    public List<Book> getComics() {
        return books.stream()
                .filter(b -> b.getType() == BookType.COMIC)
                .collect(Collectors.toList());
    }

    public List<Book> getManga() {
        return books.stream()
                .filter(b -> b.getType() == BookType.MANGA)
                .collect(Collectors.toList());
    }

    public List<Book> getPopular() {
        return books.stream().filter(Book::isPopular).collect(Collectors.toList());
    }

    public List<Book> getNew() {
        return books.stream().filter(Book::isNew).collect(Collectors.toList());
    }

    public List<Promo> getPromos() {
        return Collections.unmodifiableList(promos);
    }

    public Book getBookById(int id) {
        return books.stream().filter(b -> b.getId() == id).findFirst().orElse(null);
    }

    // ===================== Поиск =====================

    /**
     * Поиск без учёта регистра по полям: название, автор, жанр, издательство.
     * При пустом запросе возвращает весь список.
     */
    public List<Book> search(String query) {
        if (query == null || query.isBlank()) {
            return getBooks();
        }
        if (dbMode) {
            try {
                return catalogDao.search(query);
            } catch (DbException e) {
                System.err.println("[DB] Ошибка поиска, поиск в памяти: " + e.getMessage());
            }
        }
        String q = query.trim().toLowerCase();
        return books.stream()
                .filter(b -> contains(b.getTitle(), q)
                        || contains(b.getAuthor(), q)
                        || contains(b.getGenre(), q)
                        || contains(b.getPublisher(), q))
                .collect(Collectors.toList());
    }

    private boolean contains(String value, String query) {
        return value != null && value.toLowerCase().contains(query);
    }

    // ===================== Авторизация =====================

    /** Возвращает true при успешном входе и сохраняет текущего пользователя. */
    public boolean login(String email, String password) {
        if (email == null || password == null) {
            return false;
        }
        return users.stream()
                .filter(u -> u.getEmail().equalsIgnoreCase(email.trim())
                        && u.getPassword().equals(password))
                .findFirst()
                .map(u -> {
                    currentUser = u;
                    return true;
                })
                .orElse(false);
    }

    /**
     * Регистрация нового пользователя.
     * Возвращает false, если email уже занят или поля пусты.
     */
    public boolean register(String name, String email, String password, String phone, String address) {
        if (isBlank(name) || isBlank(email) || isBlank(password)) {
            return false;
        }
        boolean exists = users.stream().anyMatch(u -> u.getEmail().equalsIgnoreCase(email.trim()));
        if (exists) {
            return false;
        }
        User user = new User(name.trim(), email.trim(), password, phone, address);
        users.add(user);
        currentUser = user; // сразу выполняем вход
        return true;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void logout() {
        currentUser = null;
    }

    private boolean isBlank(String s) {
        return s == null || s.isBlank();
    }
}
